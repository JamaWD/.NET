﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Lab7.Models.DataAccess
{
    public partial class Course
    {
        public Course()
        {
            AcademicRecord = new HashSet<AcademicRecord>();
        }

        public string Code { get; set; }
        [Display(Name = "Course")]
        public string Title { get; set; }

        public ICollection<AcademicRecord> AcademicRecord { get; set; }
    }
}
