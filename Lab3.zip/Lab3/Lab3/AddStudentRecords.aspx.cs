﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AlgonquinCollege.Registration.Entities;

public partial class Default2 : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {

           if (Session["courses"] == null)
            {
                Response.Redirect("AddCourses.aspx");
            }


            if (Session["courses"] != null)
            {
                List<Course> listCourses = Session["courses"] as List<Course>;
                dropCourseSelection.DataSource = listCourses;
                dropCourseSelection.DataTextField = "CourseName";
                dropCourseSelection.DataValueField = "CourseNumber";
                dropCourseSelection.DataBind();

            }
        }


        LinkButton btnHome = (LinkButton)Master.FindControl("btnHome");
        btnHome.Click += (s, a) => Response.Redirect("Default.aspx");

        BulletedList topMenu1 = (BulletedList)Master.FindControl("topMenu");

        if (!IsPostBack)
        {

            ListItem LS1 = new ListItem("Add Course");
            topMenu1.Items.Add(LS1);

        }
        topMenu1.Click += topMenu_Click;
    }


    protected void btnSubmit_Click1(object sender, EventArgs e)
    {
        string sort = Request.Params["sort"];
        Student student = new Student(txtStudentNumber.Text, txtStudentName.Text);

        string selectedCourseCode = dropCourseSelection.SelectedValue;
        List<Course> listCourses = (List<Course>)Session["courses"];
        Course selectedCourse = listCourses.Find(x => x.CourseNumber == selectedCourseCode);

        AcademicRecord academicRecord = new AcademicRecord(selectedCourse, student);
        academicRecord.Grade = int.Parse(txtStudentGrade.Text);

        selectedCourse.AcademicRecords.Add(academicRecord);


        ShowCourseRecords(selectedCourse.AcademicRecords);

    }


    protected void ShowCourseRecords(List<AcademicRecord> listAcademicRecords)
    {

        foreach (AcademicRecord academicRecord in listAcademicRecords)
        {
            TableRow StudentRow = new TableRow();
            TableCell StudentId = new TableCell();
            TableCell StudentName = new TableCell();
            TableCell StudentGrade = new TableCell();
            StudentId.Text = academicRecord.Student.Id.ToString();
            StudentName.Text = academicRecord.Student.Name;
            StudentGrade.Text = academicRecord.Grade.ToString();


            StudentRow.Cells.Add(StudentId);
            StudentRow.Cells.Add(StudentName);
            StudentRow.Cells.Add(StudentGrade);

            tblRecord.Rows.Add(StudentRow);
        }



    }



    protected void topMenu_Click(object sender, BulletedListEventArgs e)
    {
        if (e.Index == 0)
        {
            Response.Redirect("AddCourses.aspx");
        }

    }



    protected void itemSelected(object sender, EventArgs e)
    {
        string selectedCourseCode = dropCourseSelection.SelectedValue;
        List<Course> listCourses = (List<Course>)Session["courses"];
        Course selectedCourse = listCourses.Find(x => x.CourseNumber == selectedCourseCode);

        ShowCourseRecords(selectedCourse.AcademicRecords);
    }

  

}