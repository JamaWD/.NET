﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AlgonquinCollege.Registration.Entities;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        LinkButton LB = (LinkButton)Master.FindControl("btnHome");

        BulletedList topMenu1 = (BulletedList)Master.FindControl("topMenu");

        if (!IsPostBack)
        {

            ListItem LS1 = new ListItem("Add Course");
            topMenu1.Items.Add(LS1);

            ListItem LS2 = new ListItem("Add Student Records");
            topMenu1.Items.Add(LS2);
        }
        topMenu1.Click += topMenu_Click;
    }

    protected void topMenu_Click(object sender, BulletedListEventArgs e)
    {
        if (e.Index == 0)
        {
            Response.Redirect("AddCourses.aspx");
        }
        else if (e.Index == 1)
        {
            Response.Redirect("AddStudentRecords.aspx");
        }
    }
}