﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AlgonquinCollege.Registration.Entities;


public partial class Default2 : System.Web.UI.Page
{
    static List<Course> listCourses = new List<Course>();
    protected void Page_Load(object sender, EventArgs e)
    {
        // setting up top menu
        LinkButton btnHome = (LinkButton)Master.FindControl("btnHome");
        btnHome.Click += (s, a) => Response.Redirect("Default.aspx");

        BulletedList topMenu = (BulletedList)Master.FindControl("topMenu");
        if (!IsPostBack)
        {
            topMenu.Items.Add(new ListItem("Add Student Records"));
        }
        topMenu.Click += (s, a) => Response.Redirect("AddStudentRecords.aspx");

        var courses = (List<Course>)Session["courses"];

       
    }
   

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Course course = new Course(txtCourseNumber.Text, txtCourseName.Text);
        listCourses.Add(course);
        string sort = Request.Params["sort"];
        Session["courses"] = listCourses;
        ShowCourseRecords(listCourses, sort);

    }




    protected void ShowCourseRecords(List<Course> courses, string sort)
    {

     for (int i = tblCourses.Rows.Count - 1; i > 0; i--)
            {
                tblCourses.Rows.RemoveAt(i);
            }

        if (sort == "code")
        {
            courses.Sort((c1, c2) => c1.CourseNumber.CompareTo(c2.CourseNumber));
        }
        else if (sort == "title")
        {
            courses.Sort((c1, c2) => c1.CourseName.CompareTo(c2.CourseName));
        }
        if (!string.IsNullOrEmpty(sort))
        {
            if (Session["order"] != null && (string)Session["order"] == "descending")
            {
                courses.Reverse();
                Session["order"] = "ascending";
            }
            else
            {
                Session["order"] = "descending";
            }
            Response.Redirect("AddCourse.aspx");
        }
        foreach (Course course in courses)
        {
            TableRow CourseRow = new TableRow();
            TableCell CourseNumber = new TableCell();
            TableCell CourseName = new TableCell();
            CourseNumber.Text = course.CourseNumber;
            CourseName.Text = course.CourseName;
            CourseRow.Cells.Add(CourseNumber);
            CourseRow.Cells.Add(CourseName);
            tblCourses.Rows.Add(CourseRow);
        }

    }
}