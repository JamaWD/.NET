﻿using System;
using System.Collections;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BookStore : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var cart = Session["cart"] as ShoppingCart;
        if (cart == null)
        {
            cart = new ShoppingCart();
            Session["cart"] = cart;
        }

        if (!IsPostBack)
        {
            ArrayList books = BookCatalogDataAccess.GetAllBooks();
            foreach (Book book in books)
            {
                ListItem item = new ListItem(book.Title, book.Id);
                drpBookSelection.Items.Add(item);
            }
        }


    }
    protected void drpBookSelection_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpBookSelection.SelectedIndex != 0)
        {
            string bookId = drpBookSelection.SelectedItem.Value;
            Book book = BookCatalogDataAccess.GetBookById(bookId);

            ltrDescription.Text = book.Description;
            lblPrice.Text = "$" + book.Price.ToString(CultureInfo.InvariantCulture);
        }
        else
        {
            ltrDescription.Text = string.Empty;
            lblPrice.Text = string.Empty;
        }
    }
    protected void btnAddToCart_Click(object sender, EventArgs e)
    {
        if (drpBookSelection.SelectedIndex != 0)
        {
            var cart = Session["cart"] as ShoppingCart ?? new ShoppingCart();
            var book = BookCatalogDataAccess.GetBookById(drpBookSelection.SelectedValue);
            BookOrder order = new BookOrder(book, int.Parse(txtQuantity.Text));
            cart.AddBookOrder(order);
            drpBookSelection.Items.Remove(new ListItem(book.Title,book.Id));
            txtQuantity.Text = string.Empty;
        }
    }

    protected void btnViewCart_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShoppingCartView.aspx");
    }
}