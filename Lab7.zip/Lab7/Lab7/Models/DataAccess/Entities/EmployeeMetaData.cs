﻿using System.ComponentModel.DataAnnotations;
namespace Lab7.Models.DataAccess
{
    public class EmployeeMetaData
    {
        [Required(ErrorMessage = "Employee name is required.")]
        [RegularExpression(@"[a-zA-z]+\s+[a-zA-z]+" , ErrorMessage = "Must be in the form of first name follow by last name")]
        [Display(Name = "Employee Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "User name is required.")]
        [StringLength(30, MinimumLength = 3, ErrorMessage ="User name length should be more than 3 characters.")]
        [Display(Name ="User Name")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [StringLength(30, MinimumLength = 5, ErrorMessage = "Password length should be more than 5 characters.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Role is required.")]
        public string Role { get; set; }
    }
}