﻿USE [StudentRecord]
GO

/****** Object: Table [dbo].[AcademicRecord] Script Date: 9/17/2017 10:42:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

DROP TABLE [dbo].[AcademicRecord];
GO
DROP TABLE [dbo].[Course];
GO
DROP TABLE [dbo].[Student];
GO
DROP TABLE [dbo].[Employee];
GO

CREATE TABLE [dbo].[Course] (
    [Code]  NVARCHAR (10) NOT NULL PRIMARY KEY,
    [Title] NVARCHAR (50) NOT NULL
);

CREATE TABLE [dbo].[Student] (
    [Id]   NVARCHAR (10) NOT NULL PRIMARY KEY,
    [Name] NVARCHAR (50) NOT NULL,
	[Type] NVARCHAR (10) NULL
);

CREATE TABLE [dbo].[AcademicRecord]
(
	[CourseCode] NVARCHAR(10) NOT NULL , 
    [StudentId] NVARCHAR(10) NOT NULL, 
    [Grade] INT NULL, 
    PRIMARY KEY ([StudentId], [CourseCode]), 
    CONSTRAINT [FK_AcademicRecord_Course] FOREIGN KEY ([CourseCode]) REFERENCES [Course]([Code]), 
    CONSTRAINT [FK_AcademicRecord_Student] FOREIGN KEY ([StudentId]) REFERENCES [Student]([Id]) 
)

CREATE TABLE [dbo].[Employee]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] NVARCHAR(50) NOT NULL, 
    [Role] NVARCHAR(50) NOT NULL, 
    [UserName] NVARCHAR(50) NOT NULL, 
    [Password] NVARCHAR(50) NOT NULL
)

INSERT INTO [dbo].[Course] ([Code], [Title]) VALUES (N'CST8257', N'Web Application Development')
INSERT INTO [dbo].[Course] ([Code], [Title]) VALUES (N'CST8255', N'ASP.NET  Programming')
INSERT INTO [dbo].[Course] ([Code], [Title]) VALUES (N'CST8256', N'Web Programming Language I')
INSERT INTO [dbo].[Course] ([Code], [Title]) VALUES (N'CST8259', N'Web Programming Language II')
INSERT INTO [dbo].[Course] ([Code], [Title]) VALUES (N'CST2200', N'Database Management and Administration System')

INSERT INTO [dbo].[Student] ([Id], [Name], [Type]) VALUES (N'0001', N'Wei Gong', N'Fulltime')
INSERT INTO [dbo].[Student] ([Id], [Name], [Type]) VALUES (N'0002', N'John Smith', N'Fulltime')
INSERT INTO [dbo].[Student] ([Id], [Name], [Type]) VALUES (N'0003', N'Adam Smith', N'Fulltime')
INSERT INTO [dbo].[Student] ([Id], [Name], [Type]) VALUES (N'0004', N'Jane Doe', N'Parttime')
INSERT INTO [dbo].[Student] ([Id], [Name], [Type]) VALUES (N'0006', N'May Davison', N'Parttime')
INSERT INTO [dbo].[Student] ([Id], [Name], [Type]) VALUES (N'0008', N'Peter Robinson', N'Parttime')
INSERT INTO [dbo].[Student] ([Id], [Name], [Type]) VALUES (N'0011', N'Peter Robinson', N'Coop')
INSERT INTO [dbo].[Student] ([Id], [Name], [Type]) VALUES (N'0012', N'Stephen Harp', N'Coop')

INSERT INTO [dbo].[AcademicRecord] ([CourseCode], [StudentId], [Grade]) VALUES (N'CST2200', N'0001', 70)
INSERT INTO [dbo].[AcademicRecord] ([CourseCode], [StudentId], [Grade]) VALUES (N'CST8255', N'0001', 90)
INSERT INTO [dbo].[AcademicRecord] ([CourseCode], [StudentId], [Grade]) VALUES (N'CST8255', N'0002', 70)
INSERT INTO [dbo].[AcademicRecord] ([CourseCode], [StudentId], [Grade]) VALUES (N'CST8255', N'0003', 80)
INSERT INTO [dbo].[AcademicRecord] ([CourseCode], [StudentId], [Grade]) VALUES (N'CST8255', N'0004', 90)
INSERT INTO [dbo].[AcademicRecord] ([CourseCode], [StudentId], [Grade]) VALUES (N'CST8255', N'0006', 89)
INSERT INTO [dbo].[AcademicRecord] ([CourseCode], [StudentId], [Grade]) VALUES (N'CST8255', N'0008', 85)
INSERT INTO [dbo].[AcademicRecord] ([CourseCode], [StudentId], [Grade]) VALUES (N'CST2200', N'0011', 88)
INSERT INTO [dbo].[AcademicRecord] ([CourseCode], [StudentId], [Grade]) VALUES (N'CST2200', N'0012', 65)

INSERT INTO [dbo].[Employee] ([Name], [Role], [UserName], [Password]) VALUES (N'John Smith', N'Chair', N'smithj', N'Password1')
INSERT INTO [dbo].[Employee] ([Name], [Role], [UserName], [Password]) VALUES (N'Jane Doe', N'Coordinator, Professor', N'doej', N'Password1')
INSERT INTO [dbo].[Employee] ([Name], [Role], [UserName], [Password]) VALUES (N'Wei Gong', N'Professor', N'gongw', N'Password1')


